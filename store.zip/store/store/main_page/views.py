from django.shortcuts import render
from .models import *
# Create your views here.

def index(request):
    products = ProductName.objects.all()
    context = {'products':products}
    return render(request, 'main_page/index.html', context)

def product_info(request, pk):
    products =ProductName.objects.get(id=pk)
    context = {'products': products}
    return render(request, 'main_page/product_info.html', context)